import { useEffect, useState } from "react";
import "./pokemon-card-easy.css";
import { NavLink } from "react-router";
import RankingCard from "../RankingCard/RankingCard";

function PokemonCardEasy() {

  const [pokemon, setPokemon] = useState(null);
  const [guess, setGuess] = useState("");
  const [message, setMessage] = useState("");
  const [streak, setStreak] = useState(0);
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    loadRandomPokemon();
  }, []);

  const loadRandomPokemon = () => {
    const randomId = Math.floor(Math.random() * 151) + 1; 
    fetch(`https://pokeapi.co/api/v2/pokemon/${randomId}`)
      .then((res) => res.json())
      .then((data) => setPokemon(data));
  };

  const handleGuess = () => {
    if (!pokemon) return;

    if (guess.toLowerCase().trim() === pokemon.name.toLowerCase()) {

      setStreak(prev => prev + 1);
      setMessage(`✅ Correct! It's ${pokemon.name}!`);
      setRevealed(true);

    } else {

      setMessage("❌ Wrong! Try again.");
      setRevealed(false);
    }
  };

  const playAgain = () => {
    setRevealed(false);
    setGuess("");
    setMessage("");
    loadRandomPokemon();
  };

    const skip = () => {
    setRevealed(false);
    setStreak(0);
    setGuess("");
    setMessage("");
    loadRandomPokemon();
  };

  return (
    <div id="pokemon-container1">
      {pokemon && (
        <div className="pokemon-card1">

        <p>STREAK: 🔥{streak}</p>

          <div id="link-container" >
            <NavLink to="/easy" onClick={() => setOpen(false)}>Easy</NavLink>
            <NavLink to="/normal" onClick={() => setOpen(false)}>Normal</NavLink>
            <NavLink to="/hard" onClick={() => setOpen(false)}>Hard</NavLink>
            <NavLink to="/impossible" onClick={() => setOpen(false)}>Impossible</NavLink>
          </div> 

            <img 
              src={pokemon.sprites.front_default} 
              alt={pokemon.name} 
              className="pokemon-image"
            />

          <input
            type="text"
            value={guess}
            placeholder="Enter your guess here..."
            onChange={(e) => setGuess(e.target.value)}
          />

        <div id="card-btn1"> 
          <button onClick={handleGuess} disabled={revealed} ><i class="fa-solid fa-square-check"></i> Submit</button>
          <button onClick={skip} disabled={revealed} ><i class="fa-solid fa-forward"></i> Skip It</button>
        </div>

          <p>{message}</p>

          {revealed && (  
              <button id="next1" onClick={playAgain}> <i class="fa-solid fa-circle-arrow-right"></i> Next Pokemon!</button>
          )}

        </div>
      )}

      <RankingCard></RankingCard>
    </div>
  );
}

export default PokemonCardEasy;
